export const appId = "1ddbcc4c438089951dbbdf258738c906";
export const appKey = "50b35398a7286c5b41f6b308a445c2c0";

export const secretKey = '6a5c99ce94140279';
export const masterKey = 'cfd05c5db008ad0a11cf6c592a0da9e0';
export const apiCode = 'sdrpsq';