export const rooms = [
  {
    id: 1,
    name: "打点撒大"
  },
  {
    id: 2,
    name: "dsa打点撒大dsasdadas"
  },
  {
    id: 3,
    name: "大撒大撒"
  },
  {
    id: 4,
    name: "打赏"
  }
];

export const staffes = [
  {
    id: "11",
    name: "小刘"
  },
  {
    id: "12",
    name: "小郭"
  }
];
